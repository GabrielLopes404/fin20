export const Colors = {
  primary: '#4A90E2',
  primaryDark: '#357ABD',
  primaryLight: '#6BA3E8',
  primarySurface: '#E8F2FA',
  primaryHover: '#3A7FC7',
  primaryPressed: '#2E6BA8',
  
  accent: '#FF7F5C',
  accentDark: '#E66D4A',
  accentLight: '#FF9B7F',
  accentSurface: '#FFE9E3',
  accentHover: '#F06F4C',
  
  secondary: '#2ECC71',
  secondaryDark: '#27AE60',
  secondaryLight: '#58D68D',
  secondarySurface: '#E8F8F0',
  
  background: '#FFFFFF',
  backgroundLight: '#FAFBFC',
  backgroundGray: '#F5F6F8',
  backgroundDark: '#1A1F2E',
  backgroundCard: '#FFFFFF',
  backgroundElevated: '#F8F9FA',
  backgroundSection: '#FAFBFC',
  
  textPrimary: '#2C3E50',
  textSecondary: '#546E7A',
  textTertiary: '#78909C',
  textLight: '#FFFFFF',
  textDark: '#1A252F',
  textMuted: '#90A4AE',
  textDisabled: '#CFD8DC',
  
  border: '#E0E6ED',
  borderLight: '#F0F3F7',
  borderDark: '#CBD5E0',
  borderFocus: '#4A90E2',
  borderHover: '#D1D9E3',
  
  success: '#2ECC71',
  successLight: '#D4EDDA',
  successDark: '#27AE60',
  error: '#E74C3C',
  errorLight: '#F8D7DA',
  errorDark: '#C0392B',
  warning: '#F39C12',
  warningLight: '#FFF3CD',
  warningDark: '#D68910',
  info: '#4A90E2',
  infoLight: '#D6E9F8',
  infoDark: '#357ABD',
  rating: '#F39C12',
  
  overlay: 'rgba(26, 31, 46, 0.6)',
  overlayLight: 'rgba(26, 31, 46, 0.3)',
  overlayDark: 'rgba(26, 31, 46, 0.85)',
  
  glass: {
    white: 'rgba(255, 255, 255, 0.95)',
    light: 'rgba(255, 255, 255, 0.85)',
    medium: 'rgba(255, 255, 255, 0.7)',
    dark: 'rgba(26, 31, 46, 0.9)',
    primary: 'rgba(74, 144, 226, 0.1)',
    ultraLight: 'rgba(255, 255, 255, 0.5)',
    frost: 'rgba(255, 255, 255, 0.75)',
    smoke: 'rgba(0, 0, 0, 0.05)',
  },
  
  shadow: {
    primary: 'rgba(74, 144, 226, 0.12)',
    accent: 'rgba(255, 127, 92, 0.2)',
    dark: 'rgba(44, 62, 80, 0.1)',
    colored: 'rgba(74, 144, 226, 0.15)',
    soft: 'rgba(44, 62, 80, 0.06)',
  },
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  xxxl: 32,
  huge: 40,
  massive: 48,
  xl2: 56,
};

export const BorderRadius = {
  xs: 4,
  sm: 6,
  md: 10,
  lg: 14,
  xl: 18,
  xxl: 24,
  round: 999,
};

export const FontSizes = {
  xs: 12,
  sm: 14,
  md: 16,
  lg: 18,
  xl: 20,
  xxl: 24,
  xxxl: 28,
  huge: 34,
  massive: 42,
  displayMD: 36,
  displayLG: 42,
  displayXL: 52,
};

export const FontWeights = {
  regular: '400',
  medium: '500',
  semibold: '600',
  bold: '700',
};

export const LineHeights = {
  tight: 1.15,
  snug: 1.3,
  normal: 1.45,
  relaxed: 1.6,
};

export const Shadows = {
  xs: {
    shadowColor: '#2C3E50',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.03,
    shadowRadius: 2,
    elevation: 1,
  },
  small: {
    shadowColor: '#2C3E50',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  medium: {
    shadowColor: '#2C3E50',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
  },
  large: {
    shadowColor: '#2C3E50',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 6,
  },
  xl: {
    shadowColor: '#2C3E50',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.12,
    shadowRadius: 20,
    elevation: 10,
  },
  xxl: {
    shadowColor: '#2C3E50',
    shadowOffset: { width: 0, height: 14 },
    shadowOpacity: 0.14,
    shadowRadius: 28,
    elevation: 14,
  },
  colored: {
    shadowColor: '#4A90E2',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 5,
  },
  accent: {
    shadowColor: '#FF7F5C',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 5,
  },
};

export const Animations = {
  micro: 120,
  swift: 180,
  base: 240,
  deliberate: 320,
  modal: 400,
  shimmer: 2000,
};

export const Motion = {
  easing: {
    easeOut: 'cubic-bezier(0.17, 0.67, 0.4, 0.97)',
    easeInOut: 'cubic-bezier(0.45, 0, 0.4, 1)',
    easeIn: 'cubic-bezier(0.4, 0.0, 1, 1)',
    sharp: 'cubic-bezier(0.4, 0.0, 0.6, 1)',
    smooth: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
  },
  duration: {
    micro: 120,
    swift: 180,
    base: 240,
    deliberate: 320,
    modal: 400,
    shimmer: 2000,
  },
  spring: {
    gentle: { damping: 18, stiffness: 220 },
    smooth: { damping: 22, stiffness: 240 },
    snappy: { damping: 16, stiffness: 260 },
  },
  transition: {
    fade: { duration: 240, easing: 'ease-in-out' },
    slide: { duration: 320, easing: 'ease-out' },
    scale: { duration: 180, easing: 'ease-out' },
    shimmer: { duration: 2000, easing: 'linear' },
  },
};

export const Breakpoints = {
  small: 320,
  medium: 375,
  large: 414,
  tablet: 768,
  desktop: 1024,
};

export const Layout = {
  screenPadding: Spacing.lg,
  cardPadding: Spacing.lg,
  headerHeight: 64,
  tabBarHeight: 68,
  maxWidth: 600,
  minTouchTarget: 44,
  iconSize: {
    xs: 16,
    sm: 20,
    md: 24,
    lg: 32,
    xl: 40,
    xxl: 48,
  },
  elevation: {
    flat: 0,
    low: 2,
    medium: 4,
    high: 8,
    highest: 16,
  },
};

export const Typography = {
  display: {
    fontSize: FontSizes.displayXL,
    fontWeight: FontWeights.bold,
    lineHeight: LineHeights.tight,
    letterSpacing: -0.5,
  },
  h1: {
    fontSize: FontSizes.massive,
    fontWeight: FontWeights.bold,
    lineHeight: LineHeights.tight,
    letterSpacing: -0.5,
  },
  h2: {
    fontSize: FontSizes.huge,
    fontWeight: FontWeights.bold,
    lineHeight: LineHeights.snug,
    letterSpacing: -0.25,
  },
  h3: {
    fontSize: FontSizes.xxxl,
    fontWeight: FontWeights.semibold,
    lineHeight: LineHeights.snug,
    letterSpacing: -0.25,
  },
  h4: {
    fontSize: FontSizes.xxl,
    fontWeight: FontWeights.semibold,
    lineHeight: LineHeights.snug,
    letterSpacing: 0,
  },
  h5: {
    fontSize: FontSizes.xl,
    fontWeight: FontWeights.semibold,
    lineHeight: LineHeights.snug,
    letterSpacing: 0,
  },
  h6: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.medium,
    lineHeight: LineHeights.normal,
    letterSpacing: 0,
  },
  body: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.regular,
    lineHeight: LineHeights.normal,
    letterSpacing: 0,
  },
  bodySmall: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.regular,
    lineHeight: LineHeights.normal,
    letterSpacing: 0,
  },
  caption: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.regular,
    lineHeight: LineHeights.snug,
    letterSpacing: 0,
  },
  label: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.medium,
    lineHeight: LineHeights.snug,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
};

export const Glassmorphism = {
  overlay: {
    backgroundColor: 'rgba(26, 31, 46, 0.5)',
    backdropFilter: 'blur(12px)',
    borderWidth: 0,
  },
  frosting: {
    backgroundColor: 'rgba(255, 255, 255, 0.5)',
    backdropFilter: 'blur(16px)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  light: {
    backgroundColor: Colors.backgroundCard,
  },
  medium: {
    backgroundColor: Colors.backgroundGray,
  },
  dark: {
    backgroundColor: Colors.backgroundDark,
  },
};

export const FluidSpacing = (screenWidth) => {
  const baseWidth = 375;
  const scale = screenWidth / baseWidth;
  
  return {
    xs: Math.max(4, Spacing.xs * scale),
    sm: Math.max(6, Spacing.sm * scale),
    md: Math.max(10, Spacing.md * scale),
    lg: Math.max(14, Spacing.lg * scale),
    xl: Math.max(18, Spacing.xl * scale),
    xxl: Math.max(22, Spacing.xxl * scale),
    xxxl: Math.max(28, Spacing.xxxl * scale),
  };
};
