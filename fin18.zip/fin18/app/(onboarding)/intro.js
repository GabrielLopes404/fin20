/**
 * PETSGO - ONBOARDING PROFISSIONAL
 * Design sério e corporativo inspirado em Petz
 * Marketplace premium de serviços e produtos para pets
 */

import React, { useRef, useState } from 'react';
import { View, Text, StyleSheet, Dimensions, FlatList, TouchableOpacity, StatusBar, Platform } from 'react-native';
import Animated, { 
  useSharedValue, 
  useAnimatedStyle, 
  useAnimatedScrollHandler,
  interpolate,
  Extrapolate,
  runOnJS,
} from 'react-native-reanimated';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import Button from '../../components/Button';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius, Shadows } from '../../constants/theme';

const { width, height } = Dimensions.get('window');
const isSmallDevice = width < 375;

// Slides Profissionais
const slides = [
  {
    id: '1',
    icon: 'storefront-outline',
    iconBg: Colors.primary,
    title: 'Tudo para seu Pet',
    subtitle: 'em um só lugar',
    description: 'Produtos, serviços veterinários e pet shops verificados. Qualidade e confiança garantidas.',
    features: [
      { icon: 'checkmark-circle', text: '500+ lojas parceiras', color: Colors.primary },
      { icon: 'checkmark-circle', text: '50 mil+ produtos', color: Colors.primary },
      { icon: 'checkmark-circle', text: 'Entrega rápida', color: Colors.primary },
    ],
  },
  {
    id: '2',
    icon: 'medical-outline',
    iconBg: Colors.success,
    title: 'Profissionais',
    subtitle: 'Certificados',
    description: 'Veterinários, banho e tosa, adestramento com profissionais qualificados e verificados.',
    benefits: [
      { icon: 'calendar-outline', color: Colors.accent, title: 'Agendamento Online', desc: 'Reserve em segundos' },
      { icon: 'shield-checkmark-outline', color: Colors.success, title: 'Verificados', desc: 'Certificação garantida' },
      { icon: 'location-outline', color: Colors.info, title: 'Perto de Você', desc: 'Serviços na sua região' },
      { icon: 'star-outline', color: Colors.rating, title: 'Avaliações', desc: 'Reviews verificados' },
    ],
  },
  {
    id: '3',
    icon: 'rocket-outline',
    iconBg: Colors.accent,
    title: 'Pronto para Começar?',
    subtitle: 'Cadastre-se grátis',
    description: 'Crie sua conta e tenha acesso a ofertas exclusivas, programa de fidelidade e muito mais.',
    highlights: [
      { icon: 'pricetag-outline', text: 'Ofertas Exclusivas', color: Colors.accent },
      { icon: 'gift-outline', text: 'Programa de Fidelidade', color: Colors.primary },
      { icon: 'shield-outline', text: '100% Seguro', color: Colors.success },
    ],
  },
];

function SlideContent({ item, index, scrollX }) {
  const animatedStyle = useAnimatedStyle(() => {
    const inputRange = [
      (index - 1) * width,
      index * width,
      (index + 1) * width,
    ];

    const opacity = interpolate(
      scrollX.value,
      inputRange,
      [0, 1, 0],
      Extrapolate.CLAMP
    );

    const translateY = interpolate(
      scrollX.value,
      inputRange,
      [20, 0, -20],
      Extrapolate.CLAMP
    );

    return { 
      opacity,
      transform: [{ translateY }],
    };
  });

  return (
    <View style={styles.slide}>
      <SafeAreaView style={styles.slideContent} edges={['top']}>
        <Animated.View style={[styles.content, animatedStyle]}>
          
          {/* Ícone Profissional */}
          <View style={styles.heroSection}>
            <View style={[styles.iconContainer, { backgroundColor: `${item.iconBg}15` }]}>
              <View style={[styles.iconInner, { backgroundColor: item.iconBg }]}>
                <Ionicons name={item.icon} size={40} color={Colors.textLight} />
              </View>
            </View>
          </View>

          {/* Título */}
          <View style={styles.titleSection}>
            <Text style={styles.title}>{item.title}</Text>
            <Text style={[styles.subtitle, { color: item.iconBg }]}>{item.subtitle}</Text>
            <Text style={styles.description}>{item.description}</Text>
          </View>

          {/* Conteúdo de Cada Slide */}
          <View style={styles.slideBody}>
            
            {/* Slide 1: Features List */}
            {item.features && (
              <View style={styles.featuresList}>
                {item.features.map((feature, i) => (
                  <View key={i} style={styles.featureRow}>
                    <View style={[styles.featureIconBg, { backgroundColor: `${feature.color}15` }]}>
                      <Ionicons name={feature.icon} size={20} color={feature.color} />
                    </View>
                    <Text style={styles.featureText}>{feature.text}</Text>
                  </View>
                ))}
              </View>
            )}

            {/* Slide 2: Benefits Grid */}
            {item.benefits && (
              <View style={styles.benefitsGrid}>
                {item.benefits.map((benefit, i) => (
                  <View key={i} style={styles.benefitCard}>
                    <View style={[styles.benefitIconCircle, { backgroundColor: `${benefit.color}15` }]}>
                      <Ionicons name={benefit.icon} size={24} color={benefit.color} />
                    </View>
                    <Text style={styles.benefitTitle}>{benefit.title}</Text>
                    <Text style={styles.benefitDesc}>{benefit.desc}</Text>
                  </View>
                ))}
              </View>
            )}

            {/* Slide 3: Highlights */}
            {item.highlights && (
              <View style={styles.highlightsContainer}>
                {item.highlights.map((highlight, i) => (
                  <View key={i} style={styles.highlightCard}>
                    <View style={[styles.highlightIconBg, { backgroundColor: `${highlight.color}15` }]}>
                      <Ionicons name={highlight.icon} size={22} color={highlight.color} />
                    </View>
                    <Text style={styles.highlightText}>{highlight.text}</Text>
                    <Ionicons name="arrow-forward" size={18} color={Colors.textTertiary} />
                  </View>
                ))}
              </View>
            )}

          </View>
        </Animated.View>
      </SafeAreaView>
    </View>
  );
}

function PaginationDot({ index, scrollX }) {
  const animatedStyle = useAnimatedStyle(() => {
    const inputRange = [
      (index - 1) * width,
      index * width,
      (index + 1) * width,
    ];

    const dotWidth = interpolate(
      scrollX.value,
      inputRange,
      [8, 24, 8],
      Extrapolate.CLAMP
    );

    const opacity = interpolate(
      scrollX.value,
      inputRange,
      [0.3, 1, 0.3],
      Extrapolate.CLAMP
    );

    return { width: dotWidth, opacity };
  });

  return <Animated.View style={[styles.dot, animatedStyle]} />;
}

export default function IntroScreen() {
  const router = useRouter();
  const scrollX = useSharedValue(0);
  const flatListRef = useRef(null);
  const [currentIndex, setCurrentIndex] = useState(0);

  const scrollHandler = useAnimatedScrollHandler({
    onScroll: (event) => {
      scrollX.value = event.contentOffset.x;
      const index = Math.round(event.contentOffset.x / width);
      runOnJS(setCurrentIndex)(index);
    },
  });

  const handleNext = () => {
    if (currentIndex < slides.length - 1) {
      flatListRef.current?.scrollToIndex({
        index: currentIndex + 1,
        animated: true,
      });
    } else {
      router.push('/(onboarding)/signup');
    }
  };

  const handleSkip = () => {
    router.push('/(onboarding)/login');
  };

  const isLastSlide = currentIndex === slides.length - 1;

  return (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor={Colors.background} />
      
      {!isLastSlide && (
        <SafeAreaView style={styles.skipContainer} edges={['top']}>
          <TouchableOpacity 
            onPress={handleSkip}
            style={styles.skipButton}
            activeOpacity={0.7}
          >
            <Text style={styles.skipText}>Pular</Text>
          </TouchableOpacity>
        </SafeAreaView>
      )}

      <Animated.FlatList
        ref={flatListRef}
        data={slides}
        renderItem={({ item, index }) => (
          <SlideContent item={item} index={index} scrollX={scrollX} />
        )}
        keyExtractor={(item) => item.id}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={scrollHandler}
        scrollEventThrottle={16}
        bounces={false}
        decelerationRate="fast"
      />

      <SafeAreaView style={styles.bottomContainer} edges={['bottom']}>
        <View style={styles.pagination}>
          {slides.map((_, index) => (
            <PaginationDot key={index} index={index} scrollX={scrollX} />
          ))}
        </View>

        <View style={styles.buttonsWrapper}>
          {isLastSlide ? (
            <>
              <Button
                title="Criar Minha Conta"
                onPress={() => router.push('/(onboarding)/signup')}
                variant="primary"
                fullWidth
              />
              <TouchableOpacity
                onPress={() => router.push('/(onboarding)/login')}
                style={styles.loginButton}
                activeOpacity={0.7}
              >
                <Text style={styles.loginText}>Já tenho conta</Text>
              </TouchableOpacity>
            </>
          ) : (
            <Button
              title="Continuar"
              onPress={handleNext}
              variant="primary"
              fullWidth
            />
          )}
        </View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  slide: {
    width: width,
    height: height,
    backgroundColor: Colors.background,
  },
  slideContent: {
    flex: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: isSmallDevice ? 24 : 32,
    paddingTop: isSmallDevice ? 40 : 60,
    paddingBottom: 180,
  },

  // Hero
  heroSection: {
    alignItems: 'center',
    marginBottom: isSmallDevice ? 28 : 36,
  },
  iconContainer: {
    width: 120,
    height: 120,
    borderRadius: BorderRadius.xl,
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadows.medium,
  },
  iconInner: {
    width: 80,
    height: 80,
    borderRadius: BorderRadius.lg,
    alignItems: 'center',
    justifyContent: 'center',
  },

  // Título
  titleSection: {
    alignItems: 'center',
    marginBottom: isSmallDevice ? 32 : 40,
  },
  title: {
    fontSize: isSmallDevice ? 28 : 32,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    textAlign: 'center',
    marginBottom: 4,
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: isSmallDevice ? 28 : 32,
    fontWeight: FontWeights.bold,
    textAlign: 'center',
    marginBottom: 16,
    letterSpacing: -0.5,
  },
  description: {
    fontSize: isSmallDevice ? 15 : 16,
    fontWeight: FontWeights.regular,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: 24,
    maxWidth: 320,
  },

  // Body
  slideBody: {
    flex: 1,
  },

  // Features List
  featuresList: {
    gap: 16,
    marginTop: 8,
  },
  featureRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.backgroundCard,
    padding: 16,
    borderRadius: BorderRadius.md,
    gap: 14,
    borderWidth: 1,
    borderColor: Colors.border,
    ...Shadows.xs,
  },
  featureIconBg: {
    width: 40,
    height: 40,
    borderRadius: BorderRadius.sm,
    alignItems: 'center',
    justifyContent: 'center',
  },
  featureText: {
    flex: 1,
    fontSize: 15,
    fontWeight: FontWeights.medium,
    color: Colors.textPrimary,
  },

  // Benefits Grid
  benefitsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginTop: 8,
  },
  benefitCard: {
    width: '48%',
    backgroundColor: Colors.backgroundCard,
    borderRadius: BorderRadius.md,
    padding: isSmallDevice ? 16 : 18,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.border,
    ...Shadows.xs,
  },
  benefitIconCircle: {
    width: 52,
    height: 52,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  benefitTitle: {
    fontSize: 14,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
    textAlign: 'center',
    marginBottom: 4,
  },
  benefitDesc: {
    fontSize: 12,
    fontWeight: FontWeights.regular,
    color: Colors.textTertiary,
    textAlign: 'center',
  },

  // Highlights
  highlightsContainer: {
    gap: 12,
    marginTop: 8,
  },
  highlightCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.backgroundCard,
    padding: 18,
    borderRadius: BorderRadius.md,
    gap: 14,
    borderWidth: 1,
    borderColor: Colors.border,
    ...Shadows.xs,
  },
  highlightIconBg: {
    width: 44,
    height: 44,
    borderRadius: BorderRadius.sm,
    alignItems: 'center',
    justifyContent: 'center',
  },
  highlightText: {
    flex: 1,
    fontSize: 15,
    fontWeight: FontWeights.medium,
    color: Colors.textPrimary,
  },

  // Skip
  skipContainer: {
    position: 'absolute',
    top: 0,
    right: 0,
    zIndex: 10,
    paddingRight: 20,
    paddingTop: 12,
  },
  skipButton: {
    paddingVertical: 10,
    paddingHorizontal: 18,
    backgroundColor: Colors.backgroundCard,
    borderRadius: BorderRadius.round,
    borderWidth: 1,
    borderColor: Colors.border,
    ...Shadows.xs,
  },
  skipText: {
    fontSize: 14,
    fontWeight: FontWeights.medium,
    color: Colors.textSecondary,
  },

  // Bottom
  bottomContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: isSmallDevice ? 24 : 32,
    paddingBottom: 20,
    backgroundColor: Colors.background,
    borderTopWidth: 1,
    borderTopColor: Colors.borderLight,
  },
  pagination: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 6,
    marginBottom: 24,
    marginTop: 16,
  },
  dot: {
    height: 4,
    borderRadius: BorderRadius.xs,
    backgroundColor: Colors.primary,
  },
  buttonsWrapper: {
    gap: 12,
  },
  loginButton: {
    alignItems: 'center',
    paddingVertical: 16,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: Colors.backgroundCard,
  },
  loginText: {
    fontSize: 16,
    fontWeight: FontWeights.medium,
    color: Colors.textSecondary,
  },
});
