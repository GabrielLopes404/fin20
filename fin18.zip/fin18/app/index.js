/**
 * Ponto de Entrada Principal do App
 * 
 * Redireciona usuários novos para a tela de introdução (onboarding)
 * onde verão os 3 slides premium antes de fazer login.
 * 
 * TODO: Implementar lógica para verificar se usuário já fez login
 * e redirecionar direto para /(tabs) se sim.
 */
import { Redirect } from 'expo-router';

export default function Index() {
  // Por enquanto, sempre redireciona para intro
  // Futuramente, adicionar verificação de autenticação aqui
  return <Redirect href="/(onboarding)/intro" />;
}
