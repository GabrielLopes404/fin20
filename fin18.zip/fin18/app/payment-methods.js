import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius, Shadows } from '../constants/theme';

function PaymentCard({ method, isDefault, onEdit, onDelete, onSetDefault }) {
  const getCardIcon = (brand) => {
    switch (brand.toLowerCase()) {
      case 'visa':
        return 'card';
      case 'mastercard':
        return 'card';
      case 'amex':
        return 'card';
      default:
        return 'card-outline';
    }
  };

  const getCardColor = (brand) => {
    switch (brand.toLowerCase()) {
      case 'visa':
        return '#1A1F71';
      case 'mastercard':
        return '#EB001B';
      case 'amex':
        return '#006FCF';
      default:
        return Colors.primary;
    }
  };

  return (
    <View style={styles.paymentCard}>
      <View style={styles.cardHeader}>
        <View style={styles.cardBrandContainer}>
          <View style={[styles.cardIcon, { backgroundColor: getCardColor(method.brand) + '20' }]}>
            <Ionicons name={getCardIcon(method.brand)} size={24} color={getCardColor(method.brand)} />
          </View>
          <View>
            <Text style={styles.cardBrand}>{method.brand}</Text>
            <Text style={styles.cardNumber}>•••• {method.lastFour}</Text>
          </View>
        </View>
        {isDefault && (
          <View style={styles.defaultBadge}>
            <Text style={styles.defaultText}>Principal</Text>
          </View>
        )}
      </View>

      <View style={styles.cardDetails}>
        <Text style={styles.cardHolder}>{method.holderName}</Text>
        <Text style={styles.cardExpiry}>Validade: {method.expiry}</Text>
      </View>

      <View style={styles.cardActions}>
        {!isDefault && (
          <TouchableOpacity
            style={styles.actionButton}
            onPress={onSetDefault}
            activeOpacity={0.7}
          >
            <Ionicons name="checkmark-circle-outline" size={20} color={Colors.primary} />
            <Text style={styles.actionText}>Tornar principal</Text>
          </TouchableOpacity>
        )}
        <TouchableOpacity
          style={styles.actionButton}
          onPress={onEdit}
          activeOpacity={0.7}
        >
          <Ionicons name="create-outline" size={20} color={Colors.textSecondary} />
          <Text style={styles.actionTextSecondary}>Editar</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.actionButton}
          onPress={onDelete}
          activeOpacity={0.7}
        >
          <Ionicons name="trash-outline" size={20} color={Colors.error} />
          <Text style={styles.actionTextDanger}>Excluir</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

export default function PaymentMethodsScreen() {
  const router = useRouter();
  const [paymentMethods, setPaymentMethods] = useState([
    {
      id: '1',
      type: 'credit',
      brand: 'Visa',
      lastFour: '1234',
      holderName: 'João Silva',
      expiry: '12/26',
      isDefault: true,
    },
    {
      id: '2',
      type: 'credit',
      brand: 'Mastercard',
      lastFour: '5678',
      holderName: 'João Silva',
      expiry: '03/27',
      isDefault: false,
    },
  ]);

  const handleSetDefault = (methodId) => {
    setPaymentMethods(paymentMethods.map(method => ({
      ...method,
      isDefault: method.id === methodId,
    })));
  };

  const handleDelete = (methodId) => {
    setPaymentMethods(paymentMethods.filter(method => method.id !== methodId));
  };

  const handleEdit = (method) => {
    console.log('Edit payment method:', method);
  };

  const handleAddNew = () => {
    console.log('Add new payment method');
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={styles.backButton}
          activeOpacity={0.7}
        >
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Formas de pagamento</Text>
        <View style={styles.placeholder} />
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.infoBox}>
          <Ionicons name="shield-checkmark" size={24} color={Colors.success} />
          <Text style={styles.infoText}>
            Seus dados de pagamento são protegidos com criptografia de ponta a ponta
          </Text>
        </View>

        {paymentMethods.map((method) => (
          <PaymentCard
            key={method.id}
            method={method}
            isDefault={method.isDefault}
            onEdit={() => handleEdit(method)}
            onDelete={() => handleDelete(method.id)}
            onSetDefault={() => handleSetDefault(method.id)}
          />
        ))}

        <TouchableOpacity
          style={styles.addButton}
          onPress={handleAddNew}
          activeOpacity={0.8}
        >
          <Ionicons name="add-circle" size={24} color={Colors.primary} />
          <Text style={styles.addButtonText}>Adicionar cartão</Text>
        </TouchableOpacity>

        <View style={styles.acceptedCards}>
          <Text style={styles.acceptedTitle}>Cartões aceitos</Text>
          <View style={styles.cardLogos}>
            <View style={styles.cardLogo}>
              <Ionicons name="card" size={32} color={Colors.textSecondary} />
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    backgroundColor: Colors.backgroundLight,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  backButton: {
    padding: Spacing.sm,
  },
  headerTitle: {
    fontSize: FontSizes.xl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    flex: 1,
    marginLeft: Spacing.md,
  },
  placeholder: {
    width: 40,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: Spacing.lg,
  },
  infoBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.success + '10',
    borderRadius: BorderRadius.md,
    padding: Spacing.md,
    marginBottom: Spacing.lg,
    gap: Spacing.md,
  },
  infoText: {
    flex: 1,
    fontSize: FontSizes.sm,
    color: Colors.success,
    lineHeight: 20,
  },
  paymentCard: {
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
    marginBottom: Spacing.md,
    ...Shadows.small,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: Spacing.md,
  },
  cardBrandContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
  },
  cardIcon: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardBrand: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
  },
  cardNumber: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
    letterSpacing: 2,
  },
  defaultBadge: {
    backgroundColor: Colors.primary,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.sm,
  },
  defaultText: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.semibold,
    color: Colors.backgroundLight,
  },
  cardDetails: {
    marginBottom: Spacing.md,
  },
  cardHolder: {
    fontSize: FontSizes.sm,
    color: Colors.textPrimary,
    marginBottom: Spacing.xs,
  },
  cardExpiry: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
  },
  cardActions: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: Spacing.md,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    gap: Spacing.md,
    flexWrap: 'wrap',
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
  },
  actionText: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
    color: Colors.primary,
  },
  actionTextSecondary: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
  },
  actionTextDanger: {
    fontSize: FontSizes.sm,
    color: Colors.error,
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
    borderWidth: 2,
    borderColor: Colors.primary,
    borderStyle: 'dashed',
    marginBottom: Spacing.xl,
  },
  addButtonText: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.primary,
  },
  acceptedCards: {
    alignItems: 'center',
  },
  acceptedTitle: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
    marginBottom: Spacing.md,
  },
  cardLogos: {
    flexDirection: 'row',
    gap: Spacing.md,
  },
  cardLogo: {
    width: 60,
    height: 40,
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.sm,
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadows.xs,
  },
});
