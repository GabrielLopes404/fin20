const express = require('express');
const router = express.Router();
const db = require('../database/db');
const { authenticateToken } = require('../middleware/auth');

router.use(authenticateToken);

router.get('/', async (req, res) => {
  try {
    const userId = req.user.userId;

    const result = await db.query(
      `SELECT 
        f.id as favorite_id,
        f.created_at as favorited_at,
        s.*
      FROM favorites f
      JOIN stores s ON f.store_id = s.id
      WHERE f.user_id = $1
      ORDER BY f.created_at DESC`,
      [userId]
    );

    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching favorites:', error);
    res.status(500).json({ error: 'Erro ao buscar favoritos' });
  }
});

router.post('/', async (req, res) => {
  try {
    const userId = req.user.userId;
    const { store_id } = req.body;

    if (!store_id) {
      return res.status(400).json({ error: 'store_id é obrigatório' });
    }

    const result = await db.query(
      `INSERT INTO favorites (user_id, store_id)
       VALUES ($1, $2)
       ON CONFLICT (user_id, store_id) DO NOTHING
       RETURNING *`,
      [userId, store_id]
    );

    if (result.rows.length === 0) {
      return res.status(200).json({ message: 'Loja já está nos favoritos' });
    }

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Error adding favorite:', error);
    res.status(500).json({ error: 'Erro ao adicionar favorito' });
  }
});

router.delete('/:storeId', async (req, res) => {
  try {
    const userId = req.user.userId;
    const { storeId } = req.params;

    const result = await db.query(
      'DELETE FROM favorites WHERE user_id = $1 AND store_id = $2 RETURNING *',
      [userId, storeId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Favorito não encontrado' });
    }

    res.json({ message: 'Favorito removido' });
  } catch (error) {
    console.error('Error removing favorite:', error);
    res.status(500).json({ error: 'Erro ao remover favorito' });
  }
});

module.exports = router;
