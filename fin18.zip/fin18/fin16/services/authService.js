import AsyncStorage from '@react-native-async-storage/async-storage';
import { authAPI, api } from './api';

const TOKEN_KEY = '@petsgo_auth_token';
const USER_KEY = '@petsgo_user';

class AuthService {
  constructor() {
    this.token = null;
    this.user = null;
  }

  async login(email, password) {
    try {
      const response = await authAPI.login({ email, password });
      
      if (response.token && response.user) {
        this.token = response.token;
        this.user = response.user;
        
        api.setAuthToken(response.token);
        
        await AsyncStorage.setItem(TOKEN_KEY, response.token);
        await AsyncStorage.setItem(USER_KEY, JSON.stringify(response.user));
        
        return { success: true, user: response.user };
      }
      
      return { success: false, error: 'Resposta inválida do servidor' };
    } catch (error) {
      console.error('Login error:', error);
      return { 
        success: false, 
        error: error.message || 'Erro ao fazer login' 
      };
    }
  }

  async signup(userData) {
    try {
      const response = await authAPI.signup(userData);
      
      if (response.token && response.user) {
        this.token = response.token;
        this.user = response.user;
        
        api.setAuthToken(response.token);
        
        await AsyncStorage.setItem(TOKEN_KEY, response.token);
        await AsyncStorage.setItem(USER_KEY, JSON.stringify(response.user));
        
        return { success: true, user: response.user };
      }
      
      return { success: false, error: 'Resposta inválida do servidor' };
    } catch (error) {
      console.error('Signup error:', error);
      return { 
        success: false, 
        error: error.message || 'Erro ao criar conta' 
      };
    }
  }

  async logout() {
    this.token = null;
    this.user = null;
    api.setAuthToken(null);
    
    await AsyncStorage.removeItem(TOKEN_KEY);
    await AsyncStorage.removeItem(USER_KEY);
  }

  async loadStoredAuth() {
    try {
      const token = await AsyncStorage.getItem(TOKEN_KEY);
      const userStr = await AsyncStorage.getItem(USER_KEY);
      
      if (token && userStr) {
        this.token = token;
        this.user = JSON.parse(userStr);
        api.setAuthToken(token);
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error loading stored auth:', error);
      return false;
    }
  }

  getUser() {
    return this.user;
  }

  getToken() {
    return this.token;
  }

  isAuthenticated() {
    return !!this.token;
  }
}

export const authService = new AuthService();
export default authService;
