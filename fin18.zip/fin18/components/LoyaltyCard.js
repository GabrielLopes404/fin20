import React, { useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withSpring,
  withTiming,
  interpolate,
} from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Spacing, FontSizes, FontWeights, BorderRadius, Shadows, Motion } from '../constants/theme';
import { useResponsiveLayout } from '../hooks/useResponsiveLayout';

const AnimatedTouchable = Animated.createAnimatedComponent(TouchableOpacity);

export default function LoyaltyCard({
  points = 450,
  maxPoints = 500,
  level = 'Gold',
  nextReward = 'Banho grátis',
  onPress,
}) {
  const { spacing } = useResponsiveLayout();
  const progressWidth = useSharedValue(0);
  const cardScale = useSharedValue(0.98);
  const cardOpacity = useSharedValue(0);

  const progress = Math.min(points / maxPoints, 1);

  useEffect(() => {
    cardScale.value = withTiming(1, { duration: 300 });
    cardOpacity.value = withTiming(1, { duration: 300 });
    
    progressWidth.value = withDelay(
      150,
      withTiming(progress, { duration: 600 })
    );
  }, [progress]);

  const cardAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: cardScale.value }],
    opacity: cardOpacity.value,
  }));

  const progressAnimatedStyle = useAnimatedStyle(() => ({
    width: `${progressWidth.value * 100}%`,
  }));

  const pointsAnimatedStyle = useAnimatedStyle(() => {
    return {
      opacity: progressWidth.value,
    };
  });

  return (
    <AnimatedTouchable
      style={[styles.container, { marginHorizontal: spacing.lg }, cardAnimatedStyle]}
      activeOpacity={0.95}
      onPress={onPress}
    >
      <View style={[styles.content, { padding: spacing.lg }]}>
        <View style={styles.header}>
          <View style={styles.levelBadge}>
            <Ionicons name="trophy" size={16} color={Colors.accent} />
            <Text style={styles.levelText}>{level}</Text>
          </View>

          <TouchableOpacity style={styles.infoButton} activeOpacity={0.7}>
            <Ionicons name="information-circle-outline" size={20} color={Colors.textSecondary} />
          </TouchableOpacity>
        </View>

        <Text style={styles.title}>Programa de Fidelidade</Text>

        <View style={styles.pointsContainer}>
          <Animated.Text style={[styles.points, pointsAnimatedStyle]}>
            {points}
          </Animated.Text>
          <Text style={styles.pointsLabel}>pontos</Text>
        </View>

        <View style={styles.progressSection}>
          <View style={styles.progressBackground}>
            <Animated.View style={[styles.progressBar, progressAnimatedStyle]} />
          </View>

          <View style={styles.progressInfo}>
            <Text style={styles.progressText}>
              Faltam {maxPoints - points} pts para
            </Text>
            <View style={styles.rewardBadge}>
              <Ionicons name="gift" size={14} color={Colors.accent} />
              <Text style={styles.rewardText}>{nextReward}</Text>
            </View>
          </View>
        </View>

        <View style={styles.footer}>
          <View style={styles.stat}>
            <Text style={styles.statValue}>12</Text>
            <Text style={styles.statLabel}>Compras</Text>
          </View>
          
          <View style={styles.statDivider} />
          
          <View style={styles.stat}>
            <Text style={styles.statValue}>R$ 1.240</Text>
            <Text style={styles.statLabel}>Economizado</Text>
          </View>
          
          <View style={styles.statDivider} />
          
          <View style={styles.stat}>
            <Text style={styles.statValue}>3</Text>
            <Text style={styles.statLabel}>Recompensas</Text>
          </View>
        </View>
      </View>
    </AnimatedTouchable>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: Spacing.xl,
    borderRadius: BorderRadius.lg,
    overflow: 'hidden',
    backgroundColor: Colors.backgroundCard,
    borderWidth: 1,
    borderColor: Colors.border,
    ...Shadows.medium,
  },
  content: {
    gap: Spacing.md,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  levelBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: `${Colors.accent}15`,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.round,
    gap: 6,
    borderWidth: 1,
    borderColor: Colors.accent,
  },
  levelText: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
    color: Colors.accent,
  },
  infoButton: {
    width: 32,
    height: 32,
    borderRadius: BorderRadius.sm,
    backgroundColor: Colors.backgroundGray,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.medium,
    color: Colors.textSecondary,
  },
  pointsContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: Spacing.sm,
  },
  points: {
    fontSize: 44,
    fontWeight: FontWeights.bold,
    color: Colors.primary,
    lineHeight: 52,
  },
  pointsLabel: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.medium,
    color: Colors.textSecondary,
  },
  progressSection: {
    gap: Spacing.sm,
  },
  progressBackground: {
    height: 8,
    backgroundColor: Colors.backgroundGray,
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressBar: {
    height: '100%',
    backgroundColor: Colors.accent,
    borderRadius: 4,
  },
  progressInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: Spacing.xs,
  },
  progressText: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.regular,
    color: Colors.textSecondary,
  },
  rewardBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: `${Colors.accent}15`,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: BorderRadius.xs,
    gap: 4,
  },
  rewardText: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.medium,
    color: Colors.accent,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    paddingTop: Spacing.md,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  stat: {
    alignItems: 'center',
    gap: 4,
  },
  statValue: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
  },
  statLabel: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.regular,
    color: Colors.textSecondary,
  },
  statDivider: {
    width: 1,
    height: 28,
    backgroundColor: Colors.border,
  },
});
