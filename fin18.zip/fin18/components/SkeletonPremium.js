import React, { useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withTiming,
  Easing,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Spacing, BorderRadius } from '../constants/theme';

export function SkeletonBox({ width, height, style, borderRadius = BorderRadius.md }) {
  const shimmer = useSharedValue(-1);

  useEffect(() => {
    shimmer.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 1500, easing: Easing.ease }),
        withTiming(-1, { duration: 0 })
      ),
      -1,
      false
    );
  }, []);

  const shimmerAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: shimmer.value * 200 }],
  }));

  return (
    <View style={[styles.skeleton, { width, height, borderRadius }, style]}>
      <Animated.View style={[styles.shimmerContainer, shimmerAnimatedStyle]}>
        <LinearGradient
          colors={[
            'rgba(255, 255, 255, 0)',
            'rgba(255, 255, 255, 0.8)',
            'rgba(255, 255, 255, 0)',
          ]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={styles.shimmer}
        />
      </Animated.View>
    </View>
  );
}

export function SkeletonCircle({ size, style }) {
  return (
    <SkeletonBox
      width={size}
      height={size}
      borderRadius={size / 2}
      style={style}
    />
  );
}

export function SkeletonText({ width = '100%', height = 16, style }) {
  return (
    <SkeletonBox
      width={width}
      height={height}
      borderRadius={BorderRadius.xs}
      style={style}
    />
  );
}

export function SkeletonCard({ height = 200, style }) {
  return (
    <View style={[styles.card, style]}>
      <SkeletonBox width="100%" height={height} />
    </View>
  );
}

export function SkeletonStoreCard() {
  return (
    <View style={styles.storeCard}>
      <SkeletonBox width="100%" height={180} borderRadius={BorderRadius.lg} />
      
      <View style={styles.storeCardContent}>
        <View style={styles.storeCardHeader}>
          <SkeletonText width="60%" height={20} />
          <SkeletonBox width={60} height={24} borderRadius={BorderRadius.sm} />
        </View>

        <View style={styles.storeCardTags}>
          <SkeletonBox width={60} height={20} borderRadius={BorderRadius.xs} />
          <SkeletonBox width={80} height={20} borderRadius={BorderRadius.xs} />
          <SkeletonBox width={70} height={20} borderRadius={BorderRadius.xs} />
        </View>

        <View style={styles.storeCardFooter}>
          <View style={styles.storeCardMetrics}>
            <SkeletonBox width={40} height={16} borderRadius={BorderRadius.xs} />
            <SkeletonBox width={50} height={16} borderRadius={BorderRadius.xs} />
            <SkeletonBox width={60} height={16} borderRadius={BorderRadius.xs} />
          </View>
          <SkeletonText width={80} height={16} />
        </View>
      </View>
    </View>
  );
}

export function SkeletonCategory() {
  return (
    <View style={styles.category}>
      <SkeletonBox width={85} height={85} borderRadius={BorderRadius.lg} />
      <SkeletonText width={60} height={12} style={{ marginTop: Spacing.xs }} />
    </View>
  );
}

export function SkeletonHero() {
  return (
    <View style={styles.hero}>
      <SkeletonBox width="100%" height={260} borderRadius={BorderRadius.xl} />
    </View>
  );
}

export function SkeletonHeader() {
  return (
    <View style={styles.header}>
      <SkeletonBox width="70%" height={48} borderRadius={BorderRadius.xl} />
      <SkeletonCircle size={44} />
    </View>
  );
}

export function SkeletonSearchBar() {
  return (
    <View style={styles.searchContainer}>
      <SkeletonBox width="100%" height={52} borderRadius={BorderRadius.lg} />
      
      <View style={styles.filtersRow}>
        <SkeletonBox width={80} height={36} borderRadius={BorderRadius.xl} />
        <SkeletonBox width={100} height={36} borderRadius={BorderRadius.xl} />
        <SkeletonBox width={90} height={36} borderRadius={BorderRadius.xl} />
        <SkeletonBox width={110} height={36} borderRadius={BorderRadius.xl} />
      </View>
    </View>
  );
}

export default function SkeletonPremium({ type = 'card', ...props }) {
  switch (type) {
    case 'store-card':
      return <SkeletonStoreCard {...props} />;
    case 'category':
      return <SkeletonCategory {...props} />;
    case 'hero':
      return <SkeletonHero {...props} />;
    case 'header':
      return <SkeletonHeader {...props} />;
    case 'search':
      return <SkeletonSearchBar {...props} />;
    case 'card':
    default:
      return <SkeletonCard {...props} />;
  }
}

const styles = StyleSheet.create({
  skeleton: {
    backgroundColor: Colors.backgroundGray,
    overflow: 'hidden',
  },
  shimmerContainer: {
    flex: 1,
    width: '200%',
    left: '-100%',
  },
  shimmer: {
    flex: 1,
  },
  card: {
    marginHorizontal: Spacing.lg,
    marginBottom: Spacing.lg,
  },
  storeCard: {
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.xl,
    marginHorizontal: Spacing.lg,
    marginBottom: Spacing.lg,
    overflow: 'hidden',
  },
  storeCardContent: {
    padding: Spacing.lg,
    gap: Spacing.sm,
  },
  storeCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  storeCardTags: {
    flexDirection: 'row',
    gap: Spacing.xs,
  },
  storeCardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  storeCardMetrics: {
    flexDirection: 'row',
    gap: Spacing.sm,
  },
  category: {
    alignItems: 'center',
    marginRight: Spacing.md,
  },
  hero: {
    marginHorizontal: Spacing.lg,
    marginBottom: Spacing.xl,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    gap: Spacing.md,
  },
  searchContainer: {
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    gap: Spacing.md,
  },
  filtersRow: {
    flexDirection: 'row',
    gap: Spacing.sm,
  },
});
