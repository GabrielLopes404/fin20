import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, Dimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius, Shadows } from '../constants/theme';

const { width } = Dimensions.get('window');
const CARD_WIDTH = width - Spacing.lg * 2;

export default function StoreCardPremium({ store, onPress }) {
  return (
    <TouchableOpacity
      style={styles.container}
      activeOpacity={0.9}
      onPress={onPress}
    >
      <View style={styles.imageContainer}>
        <Image
          source={{ uri: store.image }}
          style={styles.image}
          resizeMode="cover"
        />
        
        {store.discount && (
          <View style={styles.discountBadge}>
            <Text style={styles.discountText}>{store.discount}</Text>
          </View>
        )}
        
        <TouchableOpacity style={styles.favoriteButton} activeOpacity={0.8}>
          <Ionicons name="heart-outline" size={20} color={Colors.textLight} />
        </TouchableOpacity>
      </View>

      <View style={styles.content}>
        <View style={styles.header}>
          <Text style={styles.name} numberOfLines={1}>{store.name}</Text>
          <View style={[
            styles.statusBadge,
            { backgroundColor: store.isOpen ? Colors.successLight : Colors.errorLight }
          ]}>
            <View style={[
              styles.statusDot,
              { backgroundColor: store.isOpen ? Colors.success : Colors.error }
            ]} />
            <Text style={[
              styles.statusText,
              { color: store.isOpen ? Colors.success : Colors.error }
            ]}>
              {store.isOpen ? 'Aberto' : 'Fechado'}
            </Text>
          </View>
        </View>

        <View style={styles.tags}>
          {store.tags.slice(0, 3).map((tag, index) => (
            <Text key={index} style={styles.tag}>{tag}</Text>
          ))}
        </View>

        <View style={styles.footer}>
          <View style={styles.metrics}>
            <View style={styles.metric}>
              <Ionicons name="star" size={14} color={Colors.rating} />
              <Text style={styles.metricText}>{store.rating.toFixed(1)}</Text>
            </View>
            
            <View style={styles.metricDivider} />
            
            <View style={styles.metric}>
              <Ionicons name="location" size={14} color={Colors.primary} />
              <Text style={styles.metricText}>{store.distance} km</Text>
            </View>
            
            {store.deliveryTime && (
              <>
                <View style={styles.metricDivider} />
                <View style={styles.metric}>
                  <Ionicons name="time-outline" size={14} color={Colors.textSecondary} />
                  <Text style={styles.metricText}>{store.deliveryTime} min</Text>
                </View>
              </>
            )}
          </View>

          {store.deliveryFee !== undefined && (
            <Text style={styles.deliveryFee}>
              {store.deliveryFee === 0 ? 'Frete Grátis' : `R$ ${store.deliveryFee.toFixed(2)}`}
            </Text>
          )}
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    width: CARD_WIDTH,
    backgroundColor: Colors.backgroundCard,
    borderRadius: BorderRadius.md,
    marginBottom: Spacing.lg,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: Colors.border,
    ...Shadows.small,
  },
  imageContainer: {
    width: '100%',
    height: 180,
    backgroundColor: Colors.backgroundGray,
    position: 'relative',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  discountBadge: {
    position: 'absolute',
    top: Spacing.md,
    left: Spacing.md,
    backgroundColor: Colors.accent,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.xs,
  },
  discountText: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.bold,
    color: Colors.textLight,
  },
  favoriteButton: {
    position: 'absolute',
    top: Spacing.md,
    right: Spacing.md,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(0,0,0,0.3)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    padding: Spacing.lg,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.sm,
  },
  name: {
    flex: 1,
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginRight: Spacing.sm,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.sm,
    gap: Spacing.xs,
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  statusText: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.semibold,
  },
  tags: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.xs,
    marginBottom: Spacing.md,
  },
  tag: {
    fontSize: FontSizes.xs,
    color: Colors.textSecondary,
    backgroundColor: Colors.backgroundGray,
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.xs,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  metrics: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  metric: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
  },
  metricDivider: {
    width: 1,
    height: 12,
    backgroundColor: Colors.border,
  },
  metricText: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
    fontWeight: FontWeights.medium,
  },
  deliveryFee: {
    fontSize: FontSizes.sm,
    color: Colors.success,
    fontWeight: FontWeights.semibold,
  },
});
